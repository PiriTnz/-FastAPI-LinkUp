from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from database import SessionLocal, engine
from models import Base
from schemas import UserCreate, UserOut, PostCreate, PostOut
from crud import create_user, get_user_by_username, create_post, get_posts

# Create database tables if they don't exist
Base.metadata.create_all(bind=engine)

# Initialize the FastAPI application
app = FastAPI()

# Dependency: Get a database session for each request
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Endpoint: Register a new user
@app.post("/users/", response_model=UserOut)
def register_user(user: UserCreate, db: Session = Depends(get_db)):
    # Check if the username already exists
    db_user = get_user_by_username(db, user.username)
    if db_user:
        raise HTTPException(status_code=400, detail="Username already registered")
    return create_user(db, user)

# Endpoint: Create a new post
@app.post("/posts/", response_model=PostOut)
def create_new_post(post: PostCreate, db: Session = Depends(get_db)):
    # Assuming the user ID is 1 for now
    return create_post(db, post, user_id=1)

# Endpoint: List all posts with optional pagination
@app.get("/posts/", response_model=list[PostOut])
def list_posts(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return get_posts(db, skip=skip, limit=limit)