from pydantic import BaseModel
from typing import Optional

# Shared properties for the User model
class UserBase(BaseModel):
    username: str
    is_public: Optional[bool] = True  # Default: public profile

# Properties required for creating a user
class UserCreate(UserBase):
    password: str  # Password is required during registration

# Properties returned to the client
class UserOut(UserBase):
    id: int

    class Config:
        orm_mode = True  # Enable ORM compatibility for SQLAlchemy models

# Shared properties for the Post model
class PostBase(BaseModel):
    title: str
    content: str
    media_url: Optional[str] = None  # Media is optional

# Properties required for creating a post
class PostCreate(PostBase):
    pass

# Properties returned to the client
class PostOut(PostBase):
    id: int
    owner_id: int  # The ID of the post's owner

    class Config:
        orm_mode = True