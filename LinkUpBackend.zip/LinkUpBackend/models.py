from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from database import Base
from datetime import datetime

# User model for the "users" table
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)  # Unique username
    hashed_password = Column(String)  # Password will be stored in hashed form
    is_public = Column(Boolean, default=True)  # User profile visibility

# Post model for the "posts" table
class Post(Base):
    __tablename__ = "posts"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String)  # Title of the post
    content = Column(String)  # Content of the post
    media_url = Column(String)  # Optional media URL (e.g., image, video)
    created_at = Column(DateTime, default=datetime.utcnow)  # Timestamp
    owner_id = Column(Integer, ForeignKey("users.id"))  # Relationship with the user table

    # Relationship with the User model
    owner = relationship("User")