from jose import JWTError, jwt
from datetime import datetime, timedelta
from typing import Optional

# Secret key to sign the JWT
SECRET_KEY = "your_secret_key_here"  # Replace with a secure key
ALGORITHM = "HS256"  # Algorithm for encoding JWT
ACCESS_TOKEN_EXPIRE_MINUTES = 30  # Token expiration time

# Generate a new access token
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """
    Creates a JWT access token.

    :param data: A dictionary containing the payload to encode in the token.
    :param expires_delta: Optional timedelta for token expiration.
    :return: Encoded JWT as a string.
    """
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta if expires_delta else timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})  # Add expiration time to the payload
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# Verify and decode an access token
def verify_access_token(token: str):
    """
    Decodes and verifies a JWT access token.

    :param token: The encoded JWT token.
    :return: Decoded payload if valid.
    :raises: JWTError if the token is invalid or expired.
    """
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError as e:
        raise JWTError("Invalid token") from e